# folder graphic

A Pen created on CodePen.

Original URL: [https://codepen.io/AYESHA-BUKHARI/pen/ogXRQKb](https://codepen.io/AYESHA-BUKHARI/pen/ogXRQKb).

